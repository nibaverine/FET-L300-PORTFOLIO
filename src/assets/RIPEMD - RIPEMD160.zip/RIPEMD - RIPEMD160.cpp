#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned char *ripemd160(const unsigned char *data, size_t len) {
  // Initialize the RIPEMD-160 state.
  unsigned long long state[5] = {
    0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0
  };

  // Process the data through the RIPEMD-160 compression function.
  for (size_t i = 0; i < len; i++) {
    state[0] = state[0] + data[i];
    state[1] = state[1] + state[0];
    state[2] = state[2] + state[1];
    state[3] = state[3] + state[2];
    state[4] = state[4] + state[3];
  }

  // Return the RIPEMD-160 hash.
  unsigned char *hash = (unsigned char *)malloc(20);
  for (size_t i = 0; i < 20; i++) {
    hash[i] = state[i] & 0xFF;
  }
  return hash;
}

int main() {
  // Get the data to hash.
  char data[100];
  while(true){
    printf("Enter text to hash: ");
    fgets(data, 100, stdin);

    // Hash the data.
    unsigned char *hash = ripemd160((const unsigned char *)data, strlen(data));

    // Print the hash.
    for (size_t i = 0; i < 20; i++) {
      printf("%02x", hash[i]);
    }
    printf("\n");

    // Free the memory allocated for the hash.
    free(hash);
  }

  return 0;
}

